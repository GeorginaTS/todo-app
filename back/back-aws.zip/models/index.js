import usersModel from "./collections/users.js"


const models = {
    usersModel : usersModel
}
export default models
